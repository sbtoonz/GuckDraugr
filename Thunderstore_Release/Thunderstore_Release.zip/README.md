<img src="https://cdn.discordapp.com/attachments/834731701023670283/1086390676503142481/banner.png">

Prefab name:
```guckdraugr```

Enemy has a configuration for spawning/drops but is meant to explode guck

this was made by request for littleroom dev who supplied all art animation and other 3d media for this project


Feel free to hit them up for any 3d art commissions you want for your mods!
<details>
<summary>Release Notes</summary>

## V1.0.1
* Fixed issue with model not appearing

## V1.0.2
* Added enemy skill thing.... if you shoot them with a projectile that does more than 20 damage they explode :D

## V1.0.3
* Polish as requested by art author: 
  * Particle system is much more visible on death.
  * Vomit particle system is much more logical and shows origin of attack
  * Explosion particle system much more visible
  * Emission for materials fixed
</details>